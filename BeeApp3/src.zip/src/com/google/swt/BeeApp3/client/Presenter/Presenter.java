package com.google.swt.BeeApp3.client.Presenter;

import com.google.gwt.user.client.ui.HasWidgets;

public abstract interface Presenter {
	  public abstract void go(final HasWidgets container);
	}