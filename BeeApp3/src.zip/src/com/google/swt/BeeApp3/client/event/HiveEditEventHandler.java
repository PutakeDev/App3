package com.google.swt.BeeApp3.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface HiveEditEventHandler extends EventHandler
{

	void onHiveEdit(HiveEditEvent event);

}
