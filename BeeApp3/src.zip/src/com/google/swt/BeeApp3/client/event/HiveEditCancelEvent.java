package com.google.swt.BeeApp3.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.google.gwt.event.shared.GwtEvent.Type;

public class HiveEditCancelEvent extends GwtEvent<HiveEditCancelEventHandler> {
	  public static Type<HiveEditCancelEventHandler> TYPE = new Type<HiveEditCancelEventHandler>();
	  private final String id;
	  public HiveEditCancelEvent(String id)
	{
		this.id = id;
	}

	@Override
	  public Type<HiveEditCancelEventHandler> getAssociatedType() {
	    return TYPE;
	  }

	  @Override
	  protected void dispatch(HiveEditCancelEventHandler handler) {
	    handler.onHiveEditCancel(this);
	  }
}
