package com.google.swt.BeeApp3.client.event;

import com.google.gwt.event.shared.EventHandler;


public interface HiveDeleteEventHandler extends EventHandler {
	  void onHiveDeleted(HiveDeleteEvent event);


}
