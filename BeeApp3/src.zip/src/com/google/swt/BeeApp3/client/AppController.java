package com.google.swt.BeeApp3.client;

import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.HandlerManager;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HasWidgets;
import com.google.swt.BeeApp3.client.Presenter.HiveEditPresenter;
import com.google.swt.BeeApp3.client.Presenter.HivePresenter;
import com.google.swt.BeeApp3.client.Presenter.Presenter;
import com.google.swt.BeeApp3.client.event.HiveAddEvent;
import com.google.swt.BeeApp3.client.event.HiveAddEventHandler;
import com.google.swt.BeeApp3.client.event.HiveUpdatedEvent;
import com.google.swt.BeeApp3.client.event.HiveUpdatedEventHandler;
import com.google.swt.BeeApp3.client.view.HiveEditView;
import com.google.swt.BeeApp3.client.view.HiveView;
import com.google.swt.BeeApp3.shared.model.Hive;

public class AppController implements Presenter, ValueChangeHandler<String>
{
	private final HandlerManager eventBus;
	private final HiveApiAsync hiveApi;
	private HasWidgets container;

	public AppController(HiveApiAsync hiveApi, HandlerManager eventBus)
	{
		this.hiveApi = hiveApi;
		this.eventBus = eventBus;
		bind();
	}

	private void bind()
	{
		History.addValueChangeHandler(this);
		eventBus.addHandler(HiveAddEvent.TYPE, new HiveAddEventHandler()
		{
			@Override
			public void onAddHive(HiveAddEvent hiveAddEvent)
			{
				doAddNewHive();
			}

		});
		eventBus.addHandler(HiveUpdatedEvent.TYPE, new HiveUpdatedEventHandler()
		{
			
			@Override
			public void onHiveUpdated(HiveUpdatedEvent event)
			{
				History.newItem("updated");				
			}
	
		});
	}

	private void doAddNewHive()
	{
		History.newItem("add");
	}

	public void go(final HasWidgets container)
	{
		this.container = container;

		if ("".equals(History.getToken()))
		{
			History.newItem("list");
		}
		else
		{
			History.fireCurrentHistoryState();
		}
	}

	@Override
	public void onValueChange(ValueChangeEvent<String> event)
	{
		String token = event.getValue();

		if (token != null)
		{
			Presenter presenter = null;
			if (token.equals("add"))
			{
				presenter = new HiveEditPresenter(hiveApi, eventBus,
						new HiveEditView());
			}
			if (token.equals("updated"))
			{
				presenter = new HivePresenter(hiveApi, eventBus, new HiveView());
			}			
			if (token.equals("list"))
			{
				presenter = new HivePresenter(hiveApi, eventBus, new HiveView());
			}
			if (presenter != null)
			{
				presenter.go(container);
			}
		}

	}

}
