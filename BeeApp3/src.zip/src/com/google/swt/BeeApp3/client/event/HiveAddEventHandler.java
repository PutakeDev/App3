package com.google.swt.BeeApp3.client.event;

import com.google.gwt.event.shared.EventHandler;


public interface HiveAddEventHandler extends EventHandler {



	void onAddHive(HiveAddEvent hiveAddEvent);
	}