package com.google.swt.BeeApp3.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.google.swt.BeeApp3.shared.model.Hive;

/**
 * API for interacting with our tasks backend.
 */
@RemoteServiceRelativePath("api")
public interface HiveApi extends RemoteService {
  /**
   * Deletes records for the specified tasks.
   * 
   * @param tasksToDelete the IDs of tasks to delete
   * @return the key of the last task deleted
   */
  String deleteHive(String[] hiveToDelete);

  /**
   * Gets all tasks that have been persisted.
   * 
   * @return
   */
  Hive[] getHiveList();
  
  /**
   * Saves a Task to disk and gets back a server generated key as confirmation
   * of the persistence.
   * 
   * @param task the TaskData for the task we want to persist
   * @return the JDO generated key for the task
   */
  String persistHive(Hive hive);
  
  String addNewHive(Hive hive);
}
