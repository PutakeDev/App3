package com.google.swt.BeeApp3.client;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.swt.BeeApp3.shared.model.Hive;

public interface HiveApiAsync {

	void deleteHive(String[] hiveToDelete, AsyncCallback<String> callback);

	void getHiveList(AsyncCallback<Hive[]> callback);

	void persistHive(Hive hive, AsyncCallback<String> callback);
	
	void addNewHive(Hive hive, AsyncCallback<String> callback);

}
