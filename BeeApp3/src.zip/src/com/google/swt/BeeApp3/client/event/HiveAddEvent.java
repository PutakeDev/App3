package com.google.swt.BeeApp3.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.google.gwt.event.shared.GwtEvent.Type;


public class HiveAddEvent extends GwtEvent<HiveAddEventHandler> {
	  public static Type<HiveAddEventHandler> TYPE = new Type<HiveAddEventHandler>();
	  
	  @Override
	  public Type<HiveAddEventHandler> getAssociatedType() {
	    return TYPE;
	  }

	  @Override
	  protected void dispatch(HiveAddEventHandler handler) {
	    handler.onAddHive(this);
	  }
	}
