/**
 * 
 */
package com.google.swt.BeeApp3.shared.model;

import com.google.gwt.user.client.rpc.IsSerializable;

import javax.jdo.annotations.Extension;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.IdentityType;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;


/**
 * @author Erik
 *
 */
/**
 * JDO persistable TaskData.
 */
@PersistenceCapable(identityType = IdentityType.APPLICATION)  
public class Hive implements IsSerializable {

	@Persistent	
	private String barcode;
	
	private UserRoleMatrix usrRole;
	
	@PrimaryKey
	  @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	  @Extension(vendorName="datanucleus", key="gae.encoded-pk", value="true")
	  private String id;


	@Persistent
	private boolean isPersisted;


	/**
	 * 
	 */
	@Persistent
	private String location;


	@Persistent
	private Location location2;


	@Persistent
	private String name;
	@Persistent
	private String number;	
	@Persistent
	private Apiary parentApiary;
	@Persistent
	private String RFID;
	
	public Hive() {
		this.id = null;
	}
	public String getBarcode()
	{
		return barcode;
	}
	
	public String getId() {
		return id;
	}


	public String getLocation() {
		return location;
	}


	public Location getLocation2()
	{
		return location2;
	}


	public String getName() {
		return name;
	}


	public String getNumber()
	{
		return number;
	}


	public Apiary getParentApiary()
	{
		return parentApiary;
	}


	public String getRFID() {
		return RFID;
	}
	
	  public boolean isPersisted()
	{
		return isPersisted;
	}
	
	public void setBarcode(String barcode)
	{
		this.barcode = barcode;
	}


	public void setId(String id) {
		this.id = id;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public void setLocation2(Location location2)
	{
		this.location2 = location2;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setNumber(String number)
	{
		this.number = number;
	}


	public void setParentApiary(Apiary parentApiary)
	{
		this.parentApiary = parentApiary;
	}

	

	public void setPersisted(boolean isPersisted)
	{
		this.isPersisted = isPersisted;
	}


	public void setRFID(String rFID) {
		RFID = rFID;
	}


	public void setRowAsPersisted(String result) {
		this.isPersisted = true;
		
	}
	public String getDisplayName() {
		return "Hive: " + name;
	}

	@Override
	public String toString() {
		return "Hive [ID=" + id + ", location=" + location + ", name=" + name + ", RFID="
				+ RFID + "]";
	}

}
