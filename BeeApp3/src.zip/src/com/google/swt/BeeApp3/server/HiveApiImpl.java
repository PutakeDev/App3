package com.google.swt.BeeApp3.server;


import java.util.List;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;




import com.google.swt.BeeApp3.client.HiveApi;
import com.google.swt.BeeApp3.shared.model.Hive;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;

@SuppressWarnings("serial")
public class HiveApiImpl extends RemoteServiceServlet implements HiveApi {

	  /**
	 * 
	 */
	
	private final PersistenceManagerFactory pmf =
			    JDOHelper.getPersistenceManagerFactory("transactions-optional");
	
	
	public HiveApiImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String deleteHive(String[] hiveToDelete) {
		// TODO Auto-generated method stub
		return null;
	}



	  @SuppressWarnings("unchecked")
	  private List<Hive> getPersistedHives(PersistenceManager pm)
	  {
	    Query q = pm.newQuery(Hive.class);
	
	    List<Hive> persistedHives = ((List<Hive>) q.execute());
	    return persistedHives;
	  }
	
	@Override
	public Hive[] getHiveList() {
		  PersistenceManager pm = pmf.getPersistenceManager();
	      List<Hive> hives = null;

	      List<Hive> persistedHives = getPersistedHives(pm);

	      hives = (List<Hive>) pm.detachCopyAll(persistedHives);
	      pm.close();

	      return hives.toArray(new Hive[0]);
	}

	@Override
	public String persistHive(Hive hive) {
	
	        return persistNewHive(hive);

	}
	
	public String addNewHive (Hive newHive)
	{
	    PersistenceManager pm = pmf.getPersistenceManager();
	    pm.makePersistent(newHive);
	    pm.close();
	    return newHive.getId();
	}
	
private String persistNewHive(Hive newHive) {
		    PersistenceManager pm = pmf.getPersistenceManager();
		    pm.makePersistent(newHive);
		    pm.close();
		    return newHive.getId();
		  }




private String updateExistingHive(Hive existingHive) {
    String hiveId = null;
    PersistenceManager pm = pmf.getPersistenceManager();
    Transaction tx = (Transaction) pm.currentTransaction();
    try {
      ((javax.jdo.Transaction) tx).begin();
      Hive managedHive = (Hive) pm.getObjectById(Hive.class,
          existingHive.getId());
      if (managedHive != null) {
    	  managedHive.setLocation(existingHive.getLocation());
    	  managedHive.setName(existingHive.getName());
    	  managedHive.setRFID(existingHive.getRFID());
    	  hiveId = managedHive.getId();
      }
      ((javax.jdo.Transaction) tx).commit();
    } catch (Exception e) {
      if (((javax.jdo.Transaction) tx).isActive()) {
        ((javax.jdo.Transaction) tx).rollback();
      }
    } finally {
      pm.close();
    }
    return hiveId;
  }
}
